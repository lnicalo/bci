**************PURPOSE*************************

The program contains
* Group lasso using shooting algorithm (i.e., coordinate descent).
 - The method is explained in the original group lasso paper:
	M.Yuan and Y.Lin, "Model selection and estimation in regression
	with grouped variables", J.R.Statist.Soc.B (2006) vol.68, pp.49-67.

*************HOW TO USE IT********************

To see a demo of group lasso:
   % demo_group_lasso

01/14/2010 

Gunhee Kim @ CSD.CMU
